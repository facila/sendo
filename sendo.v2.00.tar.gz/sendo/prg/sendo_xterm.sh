#!/bin/bash

# version : 2.00 Octobre 2026
# auteur  : Thierry Le Gall
# contact : facila@gmx.fr
# web     : https://github.com/facila/sendo

# commande   : sendo_xterm.sh "XTERM" FUNCTION NAME PARAMETERS

# XTERM      : paramétres xterm : couleurs , police et taille de la fenêtre
# FUNCTION   : save , run ou start
# NAME       : nom de l'équipement
# PARAMETERS : paramétres pour sendo.sh

   XTERM=$1 ; shift
FUNCTION=$1
    NAME=$2

case $FUNCTION in
 save) TITRE="SAUVEGARDER"            ;;
  run) TITRE="TELECHARGER EN RUNNING" ;;
start) TITRE="TELECHARGER EN STARTUP" ;;
    *) exit ;;
esac 

xterm -title "$TITRE $NAME" $XTERM -e "$FACILA/sendo/prg/sendo.sh $*"
